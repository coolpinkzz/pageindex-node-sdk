# PageIndex JS/TS SDK (Node-first)

Unofficial Node-first TypeScript SDK for the PageIndex API.

## Install

```bash
npm i pageindex
```

## Usage

```ts
import { PageIndexClient } from "pageindex";

const client = new PageIndexClient({ apiKey: process.env.PAGEINDEX_API_KEY! });

// Upload a PDF
const { doc_id } = await client.submitDocumentFromPath({ path: "./2023-annual-report.pdf" });

// Poll until processed
let status = "processing";
while (status !== "completed") {
  const doc = await client.getTree(doc_id);
  status = doc.status;
  if (status !== "completed") await new Promise((r) => setTimeout(r, 1500));
}

// Chat (non-streaming)
const chat = await client.chatCompletions({
  doc_id,
  messages: [{ role: "user", content: "What are the key findings?" }],
});
console.log(chat.choices?.[0]?.message?.content);

// Chat (streaming)
for await (const evt of client.chatCompletionsStream({
  doc_id,
  messages: [{ role: "user", content: "Summarize section 3." }],
})) {
  if (evt.type === "data") {
    const delta = evt.data.choices?.[0]?.delta?.content ?? "";
    if (delta) process.stdout.write(delta);
  }
}
process.stdout.write("\n");
```

## Notes

- Requires **Node >= 18** (uses built-in `fetch` + `FormData`).
- Auth uses the `api_key` header as described in the PageIndex docs.

